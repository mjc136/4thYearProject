# 4thYearProject

## Installation

```bash
# Create and activate virtual environment
python -m venv venv
venv/Scripts/activate

# Install dependencies and the project in development mode
pip install -r requirements.txt

pip install -e
```